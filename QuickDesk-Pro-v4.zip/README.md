# ⚡ QuickDesk Pro v4 — Worldwide Remote Control

Full screen sharing + mouse + keyboard + file transfer + chat.
Works over LAN or internet (free Cloudflare tunnel).

## How to start

**Double-click `START.bat`** — it auto-installs Python + packages.

Or manually:
```bash
pip install websockets Pillow mss pyautogui
python quickdesk_pro.py
```

## How to use

### HOST (friend being controlled):
1. Open QuickDesk Pro → **Share My Screen**
2. Click **▶ Start Sharing**
3. Copy the address + PIN shown
4. Send to your friend
5. For worldwide access: click **Enable Tunnel**

### VIEWER (you controlling):
1. Open QuickDesk Pro → **Connect**
2. Paste address + enter PIN → **⚡ Connect Now**
3. You see their screen. Mouse/keyboard/chat/file transfer all work.

## Features
- Worldwide via Cloudflare tunnel (free, no account)
- PIN-protected connections
- Full mouse (move, click, scroll, drag)
- Full keyboard (all keys, Ctrl+C/V, Alt+Tab, Win+D, etc.)
- Multi-monitor support
- Built-in chat
- File transfer (viewer → host)
- Emergency kill: press Ctrl+Alt+Q 3× rapidly to disconnect
- 5-30 FPS adjustable, quality control
