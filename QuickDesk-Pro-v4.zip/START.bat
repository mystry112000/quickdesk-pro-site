@echo off
title QuickDesk Pro — Setup
color 0B
cls
echo.
echo  ================================================
echo    ⚡  QuickDesk Pro — One Click Setup
echo    Full Remote Control — No extra installs!
echo  ================================================
echo.

:: ── Check Python ────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% == 0 (
    echo  [✓] Python found.
    goto :packages
)

echo  [1/3] Python not found — downloading silently...
echo        This takes 1-2 minutes. Please wait.
echo.

powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\py_setup.exe'}"

if not exist "%TEMP%\py_setup.exe" (
    echo  [!] Download failed. Check internet and try again.
    pause & exit
)

"%TEMP%\py_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
set "PATH=%LOCALAPPDATA%\Programs\Python\Python311\;%LOCALAPPDATA%\Programs\Python\Python311\Scripts\;%PATH%"
timeout /t 4 /nobreak >nul

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Restart your PC, then run this file again.
    pause & exit
)
echo  [✓] Python installed!

:packages
echo.
echo  [2/3] Installing QuickDesk packages...
python -m pip install --upgrade pip --quiet 2>nul
python -m pip install websockets Pillow mss pyautogui --quiet

if %errorlevel% neq 0 (
    echo  [!] Install failed. Check internet connection.
    pause & exit
)
echo  [✓] All packages ready!

:: ── Desktop shortcut ────────────────────────────────────
echo.
echo  [3/3] Creating Desktop shortcut...
set THIS_DIR=%~dp0
echo @echo off > "%USERPROFILE%\Desktop\QuickDesk Pro.bat"
echo cd /d "%THIS_DIR%" >> "%USERPROFILE%\Desktop\QuickDesk Pro.bat"
echo python quickdesk_pro.py >> "%USERPROFILE%\Desktop\QuickDesk Pro.bat"
echo  [✓] Shortcut created on Desktop!

echo.
echo  ================================================
echo    Launching QuickDesk Pro...
echo  ================================================
echo.

cd /d "%~dp0"
python quickdesk_pro.py
exit
