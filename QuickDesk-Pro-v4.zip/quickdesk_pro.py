"""
QuickDesk Pro v4 — Worldwide Remote Control
Screen Share + Mouse + Keyboard + File Transfer + Chat
"""

import asyncio
import websockets
import mss
import pyautogui
import json
import struct
import io
import threading
import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox
import socket
import time
import subprocess
import re
import sys
import os
import random
import string
from PIL import Image, ImageTk

pyautogui.PAUSE = 0.01

KEY_MAP = {
    "return": "enter", "escape": "esc", "backspace": "backspace",
    "tab": "tab", "space": "space", "delete": "delete",
    "left": "left", "right": "right", "up": "up", "down": "down",
    "home": "home", "end": "end", "prior": "pageup", "next": "pagedown",
    "f1": "f1", "f2": "f2", "f3": "f3", "f4": "f4", "f5": "f5",
    "f6": "f6", "f7": "f7", "f8": "f8", "f9": "f9", "f10": "f10",
    "f11": "f11", "f12": "f12",
    "ctrl_l": "ctrl", "ctrl_r": "ctrl",
    "shift_l": "shift", "shift_r": "shift",
    "alt_l": "alt", "alt_r": "alt",
    "super_l": "win", "super_r": "win",
}

TK_SPECIAL = {
    "Return": "return", "Escape": "esc", "BackSpace": "backspace",
    "Tab": "tab", "space": "space", "Delete": "delete",
    "Left": "left", "Right": "right", "Up": "up", "Down": "down",
    "Home": "home", "End": "end", "Prior": "prior", "Next": "next",
    "F1": "f1", "F2": "f2", "F3": "f3", "F4": "f4", "F5": "f5",
    "F6": "f6", "F7": "f7", "F8": "f8", "F9": "f9", "F10": "f10",
    "F11": "f11", "F12": "f12",
    "Control_L": "ctrl_l", "Control_R": "ctrl_r",
    "Shift_L": "shift_l", "Shift_R": "shift_r",
    "Alt_L": "alt_l", "Alt_R": "alt_r",
    "Super_L": "super_l", "Super_R": "super_r",
}

C = {
    "bg":      "#07090f",
    "panel":   "#0e1420",
    "panel2":  "#141d2e",
    "border":  "#1a2840",
    "accent":  "#38bdf8",
    "green":   "#22d3a5",
    "red":     "#f87171",
    "yellow":  "#fbbf24",
    "purple":  "#a78bfa",
    "text":    "#e2e8f0",
    "muted":   "#4a5e78",
    "white":   "#ffffff",
    "black":   "#000000",
}

CLOUDFLARED_EXE = "cloudflared.exe"
CLOUDFLARED_URL = (
    "https://github.com/cloudflare/cloudflared/releases/latest/download/"
    "cloudflared-windows-amd64.exe"
)
FILE_CHUNK_SIZE = 65536


def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"


def generate_pin():
    chars = string.ascii_uppercase + string.digits
    return "".join(random.choice(chars) for _ in range(6))


def _get_cf_path():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, CLOUDFLARED_EXE)


def make_binary_msg(header, payload=b""):
    header_bytes = json.dumps(header).encode()
    return struct.pack("!I", len(header_bytes)) + header_bytes + payload


def parse_binary_msg(data):
    header_len = struct.unpack("!I", data[:4])[0]
    header = json.loads(data[4:4 + header_len])
    payload = data[4 + header_len:]
    return header, payload


class TunnelEngine:
    def __init__(self, port, on_url, on_log, on_error):
        self.port = port
        self.on_url = on_url
        self.on_log = on_log
        self.on_error = on_error
        self.running = False
        self.proc = None

    def start(self):
        self.running = True
        threading.Thread(target=self._run, daemon=True).start()

    def stop(self):
        self.running = False
        if self.proc:
            try:
                self.proc.kill()
            except:
                pass
            self.proc = None

    def _ensure_cloudflared(self):
        path = _get_cf_path()
        if os.path.exists(path) and os.path.getsize(path) > 5_000_000:
            self.on_log("[tunnel] cloudflared.exe ready")
            return path
        self.on_log("[tunnel] Downloading cloudflared.exe from Cloudflare (~30 MB)...")
        try:
            import urllib.request as _ur
            _ur.urlretrieve(CLOUDFLARED_URL, path)
            sz = os.path.getsize(path)
            if sz < 5_000_000:
                os.remove(path)
                return None
            self.on_log(f"[tunnel] Downloaded ({sz // 1_000_000} MB)")
            return path
        except Exception as e:
            self.on_log(f"[tunnel] Download error: {e}")
            try:
                os.remove(path)
            except:
                pass
            return None

    def _run(self):
        if not self.running:
            return
        cf = self._ensure_cloudflared()
        if not cf:
            self.on_error("Could not download cloudflared.exe — check internet.")
            return

        cmd = [cf, "tunnel", "--url", f"http://localhost:{self.port}", "--no-autoupdate"]
        self.on_log(f"[tunnel] cloudflared tunnel --url http://localhost:{self.port}")

        try:
            self.proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            )
        except PermissionError:
            try:
                os.remove(cf)
            except:
                pass
            self.on_error("Windows Defender blocked cloudflared.exe. Allow it in Windows Security, then try again.")
            return
        except Exception as e:
            self.on_error(f"Failed to start cloudflared: {e}")
            return

        url_pat = re.compile(r"https://[a-zA-Z0-9_-]+\.trycloudflare\.com")
        q = queue.Queue()

        def _reader(pipe):
            try:
                for line in pipe:
                    q.put(line)
            finally:
                q.put(None)

        threading.Thread(target=_reader, args=(self.proc.stdout,), daemon=True).start()
        threading.Thread(target=_reader, args=(self.proc.stderr,), daemon=True).start()

        url_found = False
        done = 0
        while done < 2 and self.running:
            try:
                line = q.get(timeout=0.5)
            except:
                if self.proc.poll() is not None:
                    break
                continue
            if line is None:
                done += 1
                continue
            low = line.lower()
            if any(k in low for k in ["error", "warn", "tunnel", "url", "trycloudflare", "failed", "ready"]):
                self.on_log(f"  [cf] {line.strip()}")
            m = url_pat.search(line)
            if m:
                hostname = m.group(0).replace("https://", "")
                self.on_url(hostname)
                url_found = True

        if not url_found and self.running:
            self.on_error(
                "Cloudflare tunnel failed. Check internet or firewall.\n"
                "Try switching networks."
            )


class HostEngine:
    def __init__(self, port, fps_fn, quality_fn, pin, on_event, on_log, on_chat, on_file):
        self.port = port
        self.fps_fn = fps_fn
        self.quality_fn = quality_fn
        self.pin = pin
        self.on_event = on_event
        self.on_log = on_log
        self.on_chat = on_chat
        self.on_file = on_file
        self.viewers = set()
        self.running = False
        self.loop = None
        self.authenticated = set()
        self._file_receives = {}

    def start(self):
        self.running = True
        threading.Thread(target=self._run, daemon=True).start()

    def stop(self):
        self.running = False
        if self.loop:
            try:
                self.loop.call_soon_threadsafe(self.loop.stop)
            except:
                pass

    def _run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_until_complete(self._serve())
        except:
            pass

    async def _serve(self):
        async with websockets.serve(
            self._handle, "0.0.0.0", self.port,
            max_size=50 * 1024 * 1024, ping_interval=15, ping_timeout=10,
        ):
            self.on_log(f"Server listening on port {self.port}")
            while self.running:
                await asyncio.sleep(0.2)

    async def _handle(self, ws):
        addr = ws.remote_address[0]
        self.on_log(f"Connection from {addr}")
        auth_ok = False
        try:
            async for msg in ws:
                if isinstance(msg, str):
                    data = json.loads(msg)
                    if not auth_ok:
                        if data.get("type") == "auth" and data.get("pin") == self.pin:
                            auth_ok = True
                            self.authenticated.add(ws)
                            self.viewers.add(ws)
                            self.on_event("connect", len(self.viewers))
                            self.on_log(f"Viewer authenticated: {addr}")
                            await ws.send(json.dumps({"type": "auth_ok"}))
                            s = asyncio.create_task(self._stream(ws))
                            r = asyncio.create_task(self._recv_controls(ws))
                            done, pending = await asyncio.wait(
                                [s, r], return_when=asyncio.FIRST_COMPLETED
                            )
                            for t in pending:
                                t.cancel()
                            break
                        else:
                            await ws.send(json.dumps({"type": "auth_fail"}))
                            await asyncio.sleep(0.5)
                            break
                    if data.get("type") == "chat":
                        self.on_chat(data["text"], "viewer")
                        for v in self.viewers:
                            if v != ws:
                                try:
                                    await v.send(json.dumps({"type": "chat", "text": data["text"], "from": "viewer"}))
                                except:
                                    pass
        except Exception as e:
            self.on_log(f"Session error: {e}")
        finally:
            self.viewers.discard(ws)
            self.authenticated.discard(ws)
            self.on_event("disconnect", len(self.viewers))

    async def _stream(self, ws):
        with mss.mss() as sct:
            monitor = sct.monitors[0]
            left = monitor["left"]
            top = monitor["top"]
            real_w = monitor["width"]
            real_h = monitor["height"]
            seq = 0
            frame_ready = True

            while self.running:
                if not frame_ready:
                    await asyncio.sleep(0.005)
                    continue

                fps = max(1, self.fps_fn())
                quality = max(10, min(95, self.quality_fn()))
                interval = 1.0 / fps

                try:
                    grab = sct.grab(monitor)
                    img = Image.frombytes("RGB", grab.size, grab.bgra, "raw", "BGRX")
                    scale = 0.4 + quality / 250
                    nw = max(800, int(real_w * scale))
                    nh = max(600, int(real_h * scale))
                    img = img.resize((nw, nh), Image.BILINEAR)
                    buf = io.BytesIO()
                    img.save(buf, "JPEG", quality=quality)
                    jpeg_bytes = buf.getvalue()

                    msg = make_binary_msg({
                        "type": "frame", "w": nw, "h": nh,
                        "rw": real_w, "rh": real_h,
                        "left": left, "top": top,
                        "seq": seq,
                    }, jpeg_bytes)
                    seq += 1
                    frame_ready = False
                    await ws.send(msg)
                    frame_ready = True
                    await asyncio.sleep(interval)

                except websockets.exceptions.ConnectionClosed:
                    break
                except Exception:
                    frame_ready = True
                    await asyncio.sleep(0.05)

    async def _recv_controls(self, ws):
        async for msg in ws:
            try:
                if isinstance(msg, str):
                    d = json.loads(msg)
                    t = d.get("type")

                    if t == "mouse_move":
                        pyautogui.moveTo(d["x"], d["y"], _pause=False)
                    elif t == "mouse_click":
                        btn = d.get("button", "left")
                        pyautogui.click(d["x"], d["y"], button=btn, _pause=False)
                    elif t == "mouse_double":
                        pyautogui.doubleClick(d["x"], d["y"], _pause=False)
                    elif t == "mouse_down":
                        pyautogui.mouseDown(d["x"], d["y"], button=d.get("button", "left"), _pause=False)
                    elif t == "mouse_up":
                        pyautogui.mouseUp(d["x"], d["y"], button=d.get("button", "left"), _pause=False)
                    elif t == "mouse_scroll":
                        pyautogui.scroll(int(d["amount"]), x=d["x"], y=d["y"], _pause=False)
                    elif t == "key_down":
                        k = KEY_MAP.get(d["key"], d["key"])
                        pyautogui.keyDown(k, _pause=False)
                    elif t == "key_up":
                        k = KEY_MAP.get(d["key"], d["key"])
                        pyautogui.keyUp(k, _pause=False)
                    elif t == "key_press":
                        k = KEY_MAP.get(d["key"], d["key"])
                        if k and (len(k) == 1 or k in pyautogui.KEYBOARD_KEYS):
                            pyautogui.press(k, _pause=False)
                    elif t == "type_text":
                        txt = d.get("text", "")
                        if txt:
                            pyautogui.write(txt, interval=0.005, _pause=False)
                    elif t == "chat":
                        self.on_chat(d["text"], "viewer")
                    elif t == "file_start":
                        self._file_receives[d["id"]] = {
                            "name": d["name"], "size": d["size"],
                            "received": 0,
                        }
                        self.on_log(f"Receiving file: {d['name']} ({d['size']} bytes)")
                    elif t == "file_end":
                        self._handle_file_end(d["id"])

                else:
                    header, payload = parse_binary_msg(msg)
                    if header["type"] == "file_chunk":
                        self._handle_file_chunk(header, payload)

            except:
                pass

    def _handle_file_chunk(self, header, payload):
        file_id = header["id"]
        seq = header["seq"]
        if file_id not in self._file_receives:
            return
        info = self._file_receives[file_id]
        if seq == 0:
            try:
                downloads = os.path.join(os.path.expanduser("~"), "Downloads", "QuickDesk")
                os.makedirs(downloads, exist_ok=True)
                path = os.path.join(downloads, info["name"])
                info["path"] = path
                info["file"] = open(path, "wb")
            except Exception as e:
                self.on_log(f"File save error: {e}")
                return
        info["file"].write(payload)
        info["received"] += len(payload)
        pct = int(info["received"] * 100 / info["size"]) if info["size"] > 0 else 0
        if pct % 10 == 0 and pct != info.get("last_pct"):
            info["last_pct"] = pct
            self.on_log(f"Receiving {info['name']}: {pct}%")

    def _handle_file_end(self, file_id):
        if file_id not in self._file_receives:
            return
        info = self._file_receives.pop(file_id)
        if "file" in info:
            try:
                info["file"].close()
                self.on_log(f"Received: {info['name']} ({info['received']} bytes)")
            except Exception as e:
                self.on_log(f"File save error: {e}")


class ViewerEngine:
    def __init__(self, on_frame, on_status, on_disconnect, on_log, on_chat, on_file_progress):
        self.on_frame = on_frame
        self.on_status = on_status
        self.on_disconnect = on_disconnect
        self.on_log = on_log
        self.on_chat = on_chat
        self.on_file_progress = on_file_progress
        self.ws = None
        self.loop = None
        self.running = False
        self.pin = ""
        self.address = ""
        self._receive_task = None

    def connect(self, address, pin):
        self.address = address.strip()
        self.pin = pin.strip()
        if "trycloudflare.com" in self.address:
            if not self.address.startswith("wss://"):
                self.address = "wss://" + self.address.replace("https://", "").replace("http://", "")
        elif not self.address.startswith("ws"):
            self.address = "ws://" + self.address
        self.running = True
        threading.Thread(target=self._run, daemon=True).start()

    def disconnect(self):
        self.running = False
        if self.loop and self.ws:
            asyncio.run_coroutine_threadsafe(self._close(), self.loop)

    async def _close(self):
        try:
            await self.ws.close()
        except:
            pass

    def send_text(self, data):
        if self.ws and self.running and self.loop:
            asyncio.run_coroutine_threadsafe(self._send_text(json.dumps(data)), self.loop)

    def send_binary(self, header, payload=b""):
        if self.ws and self.running and self.loop:
            msg = make_binary_msg(header, payload)
            asyncio.run_coroutine_threadsafe(self._send_binary(msg), self.loop)

    async def _send_text(self, msg):
        try:
            await self.ws.send(msg)
        except:
            pass

    async def _send_binary(self, msg):
        try:
            await self.ws.send(msg)
        except:
            pass

    def _run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._connect())

    async def _connect(self):
        try:
            async with websockets.connect(
                self.address, max_size=50 * 1024 * 1024,
                ping_interval=15, ping_timeout=10,
            ) as ws:
                self.ws = ws
                await ws.send(json.dumps({"type": "auth", "pin": self.pin}))
                resp = await ws.recv()
                if isinstance(resp, str):
                    d = json.loads(resp)
                    if d.get("type") == "auth_fail":
                        self.on_status("auth_fail")
                        self.on_log("Authentication failed — wrong PIN")
                        return
                    if d.get("type") != "auth_ok":
                        self.on_status("error")
                        self.on_log("Unexpected auth response")
                        return
                else:
                    self.on_status("error")
                    self.on_log("Unexpected auth response")
                    return

                self.on_status("connected")
                self.on_log(f"Connected to {self.address}")

                async for msg in ws:
                    if not self.running:
                        break
                    try:
                        if isinstance(msg, str):
                            d = json.loads(msg)
                            t = d.get("type")
                            if t == "frame":
                                pass
                            elif t == "chat":
                                self.on_chat(d["text"], d.get("from", "host"))
                            elif t == "file_start":
                                self._receive_file_start(d)
                            elif t == "file_chunk":
                                self._receive_file_chunk(d, b"")
                            elif t == "file_end":
                                self._receive_file_end(d)
                        else:
                            header, payload = parse_binary_msg(msg)
                            if header["type"] == "frame":
                                self.on_frame(
                                    payload, header["w"], header["h"],
                                    header["rw"], header["rh"],
                                    header.get("left", 0), header.get("top", 0),
                                )
                    except:
                        pass

        except websockets.exceptions.ConnectionRefusedError:
            self.on_status("error")
            self.on_log("Connection refused — is the host running?")
        except websockets.exceptions.InvalidStatus as e:
            if e.response and e.response.status_code == 426:
                self.on_status("error")
                self.on_log("Connection failed — Cloudflare tunnel may need HTTPS. Try using the tunnel.")
            else:
                self.on_status("error")
                self.on_log(f"Connection failed: {e}")
        except Exception as e:
            self.on_status("error")
            self.on_log(f"Connection error: {e}")
        finally:
            self.running = False
            self.on_disconnect()

    def _receive_file_start(self, header):
        pass

    def _receive_file_chunk(self, header, payload):
        pass

    def _receive_file_end(self, header):
        pass


class QuickDeskApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("QuickDesk Pro")
        self.geometry("1024x680")
        self.minsize(840, 540)
        self.configure(bg=C["bg"])
        self.resizable(True, True)

        self.host_engine = None
        self.viewer_engine = None
        self.tunnel_engine = None
        self.view = "home"
        self._fps_val = 20
        self._quality_val = 60
        self._tunnel_addr = None

        self._remote_w = 1920
        self._remote_h = 1080
        self._remote_left = 0
        self._remote_top = 0
        self._display_w = 0
        self._display_h = 0
        self._x_off = 0
        self._y_off = 0
        self._frame_count = 0
        self._fps_time = time.time()
        self._last_photo = None

        self._mods_held = set()

        self._kill_count = 0
        self._kill_time = 0

        self._file_receives = {}

        self._build_layout()
        self.show_home()
        self.protocol("WM_DELETE_WINDOW", self._quit)

    def _build_layout(self):
        self.sidebar = tk.Frame(self, bg=C["panel"], width=210)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)
        self._build_sidebar()

        tk.Frame(self, bg=C["border"], width=1).pack(side=tk.LEFT, fill=tk.Y)

        self.content = tk.Frame(self, bg=C["bg"])
        self.content.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    def _build_sidebar(self):
        logo = tk.Frame(self.sidebar, bg=C["panel"], pady=22, padx=18)
        logo.pack(fill=tk.X)
        tk.Label(logo, text="⚡", font=("Segoe UI Emoji", 24),
                 bg=C["panel"], fg=C["accent"]).pack(anchor="w")
        tk.Label(logo, text="QuickDesk Pro", font=("Segoe UI", 13, "bold"),
                 bg=C["panel"], fg=C["text"]).pack(anchor="w", pady=(4, 0))
        tk.Label(logo, text="Worldwide Remote Control", font=("Segoe UI", 8),
                 bg=C["panel"], fg=C["muted"]).pack(anchor="w")

        tk.Frame(self.sidebar, bg=C["border"], height=1).pack(fill=tk.X)

        nav = tk.Frame(self.sidebar, bg=C["panel"], pady=10)
        nav.pack(fill=tk.X)

        self._nb = {}
        for icon, label, key in [
            ("🏠", "Home", "home"),
            ("🖥", "Share Screen", "host"),
            ("👁", "Connect", "viewer"),
        ]:
            b = tk.Button(nav, text=f"  {icon}  {label}",
                          font=("Segoe UI", 10), bg=C["panel"], fg=C["muted"],
                          activebackground=C["panel2"], activeforeground=C["text"],
                          relief=tk.FLAT, anchor="w", padx=4, pady=10,
                          cursor="hand2", bd=0,
                          command=lambda k=key: self._nav(k))
            b.pack(fill=tk.X)
            self._nb[key] = b

        tk.Frame(self.sidebar, bg=C["border"], height=1).pack(fill=tk.X)

        bot = tk.Frame(self.sidebar, bg=C["panel"], padx=16, pady=14)
        bot.pack(side=tk.BOTTOM, fill=tk.X)
        tk.Frame(self.sidebar, bg=C["border"], height=1).pack(side=tk.BOTTOM, fill=tk.X)
        self._ip_lbl = tk.Label(bot, text=f"IP: {get_local_ip()}",
                                font=("Courier", 8), bg=C["panel"], fg=C["muted"])
        self._ip_lbl.pack(anchor="w")
        tk.Label(bot, text="v4 — Worldwide",
                 font=("Segoe UI", 8), bg=C["panel"], fg=C["muted"]).pack(anchor="w")

    def _nav(self, key):
        if key == "home":
            self.show_home()
        elif key == "host":
            self.show_host()
        elif key == "viewer":
            self.show_viewer()

    def _set_nav(self, active):
        for k, b in self._nb.items():
            if k == active:
                b.configure(bg=C["panel2"], fg=C["accent"])
            else:
                b.configure(bg=C["panel"], fg=C["muted"])

    def _clear(self):
        for w in self.content.winfo_children():
            w.destroy()

    def show_home(self):
        self._clear()
        self._set_nav("home")
        self.view = "home"

        f = tk.Frame(self.content, bg=C["bg"], padx=44, pady=38)
        f.pack(fill=tk.BOTH, expand=True)

        tk.Label(f, text="Welcome to QuickDesk Pro",
                 font=("Segoe UI", 20, "bold"), bg=C["bg"], fg=C["text"]).pack(anchor="w")
        tk.Label(f, text="Full screen sharing + mouse & keyboard. Works worldwide via Cloudflare tunnel.",
                 font=("Segoe UI", 10), bg=C["bg"], fg=C["muted"]).pack(anchor="w", pady=(4, 26))

        cards = tk.Frame(f, bg=C["bg"])
        cards.pack(anchor="w")

        self._hcard(cards, "🖥", "Share My Screen",
                    "Your friend connects to you.\nThey see and control your screen.\nPIN-protected.",
                    C["accent"], self.show_host).pack(side=tk.LEFT, padx=(0, 14))

        self._hcard(cards, "👁", "Connect to Remote",
                    "You connect to your friend.\nYou control their screen.\nEnter address + PIN.",
                    C["green"], self.show_viewer).pack(side=tk.LEFT)

        self._make_info_section(f)

    def _make_info_section(self, parent):
        how = tk.Frame(parent, bg=C["panel"], padx=22, pady=18)
        how.pack(fill=tk.X, pady=(28, 0))
        tk.Label(how, text="💡  How it works",
                 font=("Segoe UI", 10, "bold"), bg=C["panel"], fg=C["text"]).pack(anchor="w")

        for title, desc in [
            ("Friend (HOST)", "Opens QuickDesk → Share My Screen → Start → gets address + PIN"),
            ("Friend", "Sends address and PIN to you on WhatsApp/chat"),
            ("You (VIEWER)", "Opens QuickDesk → Connect → enters address + PIN → Connect"),
            ("Done!", "You see and control their screen. Chat, send files, etc."),
        ]:
            r = tk.Frame(how, bg=C["panel"])
            r.pack(anchor="w", pady=2)
            tk.Label(r, text=f"  {title}:", font=("Segoe UI", 9, "bold"),
                     bg=C["panel"], fg=C["accent"], width=18, anchor="w").pack(side=tk.LEFT)
            tk.Label(r, text=desc, font=("Segoe UI", 9),
                     bg=C["panel"], fg=C["muted"]).pack(side=tk.LEFT)

        badges = tk.Frame(parent, bg=C["bg"])
        badges.pack(anchor="w", pady=(18, 0))
        for icon, label, color in [
            ("🖱", "Mouse Control", C["green"]),
            ("⌨", "Keyboard Control", C["accent"]),
            ("📺", "Screen Sharing", C["purple"]),
            ("🌐", "Worldwide", C["yellow"]),
            ("🔒", "PIN Protected", C["red"]),
            ("💬", "Chat", C["accent"]),
            ("📁", "File Transfer", C["green"]),
        ]:
            b = tk.Frame(badges, bg=C["panel2"], padx=12, pady=6)
            b.pack(side=tk.LEFT, padx=(0, 8))
            tk.Label(b, text=f"{icon} {label}", font=("Segoe UI", 9, "bold"),
                     bg=C["panel2"], fg=color).pack()

    def _hcard(self, parent, icon, title, desc, color, cmd):
        card = tk.Frame(parent, bg=C["panel"], padx=22, pady=20, width=210, cursor="hand2")
        card.pack_propagate(False)

        def enter(e):
            card.configure(bg=C["panel2"])
            for w in card.winfo_children():
                w.configure(bg=C["panel2"])

        def leave(e):
            card.configure(bg=C["panel"])
            for w in card.winfo_children():
                w.configure(bg=C["panel"])

        card.bind("<Enter>", enter)
        card.bind("<Leave>", leave)
        card.bind("<Button-1>", lambda e: cmd())

        tk.Label(card, text=icon, font=("Segoe UI Emoji", 26),
                 bg=C["panel"]).pack(anchor="w")
        tk.Label(card, text=title, font=("Segoe UI", 12, "bold"),
                 bg=C["panel"], fg=C["text"]).pack(anchor="w", pady=(8, 3))
        tk.Label(card, text=desc, font=("Segoe UI", 9),
                 bg=C["panel"], fg=C["muted"], justify=tk.LEFT).pack(anchor="w")
        tk.Button(card, text="Open →", font=("Segoe UI", 9, "bold"),
                  bg=color, fg=C["black"], relief=tk.FLAT,
                  padx=14, pady=5, cursor="hand2", command=cmd).pack(anchor="w", pady=(12, 0))
        return card

    def show_host(self):
        self._clear()
        self._set_nav("host")
        self.view = "host"

        outer = tk.Frame(self.content, bg=C["bg"], padx=40, pady=30)
        outer.pack(fill=tk.BOTH, expand=True)

        tk.Label(outer, text="Share My Screen",
                 font=("Segoe UI", 18, "bold"), bg=C["bg"], fg=C["text"]).pack(anchor="w")
        tk.Label(outer, text="Start sharing — send the address and PIN to your friend.",
                 font=("Segoe UI", 9), bg=C["bg"], fg=C["muted"]).pack(anchor="w", pady=(3, 18))

        srow = tk.Frame(outer, bg=C["panel"], padx=16, pady=12)
        srow.pack(fill=tk.X, pady=(0, 14))

        pc = tk.Frame(srow, bg=C["panel"])
        pc.pack(side=tk.LEFT, padx=(0, 24))
        tk.Label(pc, text="PORT", font=("Courier", 8), bg=C["panel"], fg=C["muted"]).pack(anchor="w")
        self._port_var = tk.StringVar(value="8765")
        tk.Entry(pc, textvariable=self._port_var, width=7,
                 bg=C["panel2"], fg=C["accent"], insertbackground=C["white"],
                 relief=tk.FLAT, font=("Courier", 12)).pack()

        fc = tk.Frame(srow, bg=C["panel"])
        fc.pack(side=tk.LEFT, padx=(0, 24))
        tk.Label(fc, text="FPS", font=("Courier", 8), bg=C["panel"], fg=C["muted"]).pack(anchor="w")
        self._fps_var = tk.IntVar(value=20)
        tk.Scale(fc, from_=5, to=30, orient=tk.HORIZONTAL, variable=self._fps_var,
                 bg=C["panel"], fg=C["text"], highlightthickness=0,
                 troughcolor=C["panel2"], activebackground=C["accent"],
                 length=120, showvalue=True,
                 command=lambda v: setattr(self, "_fps_val", int(float(v)))).pack()

        qc = tk.Frame(srow, bg=C["panel"])
        qc.pack(side=tk.LEFT)
        tk.Label(qc, text="QUALITY", font=("Courier", 8), bg=C["panel"], fg=C["muted"]).pack(anchor="w")
        self._quality_var = tk.IntVar(value=60)
        tk.Scale(qc, from_=10, to=90, orient=tk.HORIZONTAL, variable=self._quality_var,
                 bg=C["panel"], fg=C["text"], highlightthickness=0,
                 troughcolor=C["panel2"], activebackground=C["accent"],
                 length=120, showvalue=True,
                 command=lambda v: setattr(self, "_quality_val", int(float(v)))).pack()

        abox = tk.Frame(outer, bg=C["panel2"], padx=18, pady=14)
        abox.pack(fill=tk.X, pady=(0, 12))
        tk.Label(abox, text="YOUR ADDRESS  —  send this to your friend",
                 font=("Courier", 8), bg=C["panel2"], fg=C["muted"]).pack(anchor="w")

        arow = tk.Frame(abox, bg=C["panel2"])
        arow.pack(fill=tk.X, pady=(8, 0))
        self._addr_lbl = tk.Label(arow, text="Not started",
                                  font=("Courier", 16, "bold"),
                                  bg=C["panel2"], fg=C["muted"])
        self._addr_lbl.pack(side=tk.LEFT)
        self._copy_btn = tk.Button(arow, text="📋 Copy", font=("Segoe UI", 9),
                                   bg=C["panel"], fg=C["text"], relief=tk.FLAT,
                                   padx=10, pady=4, cursor="hand2",
                                   command=self._copy_addr)
        self._copy_btn.pack(side=tk.RIGHT)

        pbox = tk.Frame(outer, bg=C["panel2"], padx=18, pady=14)
        pbox.pack(fill=tk.X, pady=(0, 12))
        self._pin_lbl = tk.Label(pbox, text="PIN: --- ---",
                                 font=("Courier", 20, "bold"),
                                 bg=C["panel2"], fg=C["yellow"])
        self._pin_lbl.pack(anchor="w")
        tk.Label(pbox, text="Your friend needs this PIN to connect",
                 font=("Courier", 8), bg=C["panel2"], fg=C["muted"]).pack(anchor="w")

        tbox = tk.Frame(outer, bg=C["panel"], padx=16, pady=10)
        tbox.pack(fill=tk.X, pady=(0, 12))
        th = tk.Frame(tbox, bg=C["panel"])
        th.pack(fill=tk.X)
        tk.Label(th, text="🌐  Internet Access (Cloudflare Tunnel)",
                 font=("Segoe UI", 9, "bold"), bg=C["panel"], fg=C["text"]).pack(side=tk.LEFT)
        self._tunnel_btn = tk.Button(th, text="Enable Tunnel",
                                     font=("Segoe UI", 8), bg=C["panel2"],
                                     fg=C["yellow"], relief=tk.FLAT, padx=8, pady=3,
                                     cursor="hand2", command=self._toggle_tunnel)
        self._tunnel_btn.pack(side=tk.RIGHT)
        self._tunnel_lbl = tk.Label(tbox, text="Tunnel OFF — only works on same network",
                                    font=("Courier", 8), bg=C["panel"], fg=C["muted"])
        self._tunnel_lbl.pack(anchor="w", pady=(5, 0))

        sbox = tk.Frame(outer, bg=C["panel"], padx=16, pady=10)
        sbox.pack(fill=tk.X, pady=(0, 12))
        srow2 = tk.Frame(sbox, bg=C["panel"])
        srow2.pack(fill=tk.X)
        self._hdot = tk.Label(srow2, text="●", font=("Segoe UI", 10),
                              bg=C["panel"], fg=C["muted"])
        self._hdot.pack(side=tk.LEFT)
        self._hstatus = tk.Label(srow2, text="Server not started",
                                 font=("Segoe UI", 9), bg=C["panel"], fg=C["muted"])
        self._hstatus.pack(side=tk.LEFT, padx=8)
        self._viewer_count = tk.Label(srow2, text="",
                                      font=("Segoe UI", 9), bg=C["panel"], fg=C["green"])
        self._viewer_count.pack(side=tk.RIGHT)

        brow = tk.Frame(outer, bg=C["bg"])
        brow.pack(anchor="w", pady=(0, 10))
        self._start_btn = tk.Button(brow, text="▶  Start Sharing",
                                    font=("Segoe UI", 11, "bold"),
                                    bg=C["green"], fg=C["black"],
                                    relief=tk.FLAT, padx=20, pady=9,
                                    cursor="hand2", command=self._start_host)
        self._start_btn.pack(side=tk.LEFT)
        tk.Button(brow, text="⏹  Stop", font=("Segoe UI", 10),
                  bg=C["panel2"], fg=C["red"], relief=tk.FLAT,
                  padx=14, pady=9, cursor="hand2",
                  command=self._stop_host).pack(side=tk.LEFT, padx=10)

        lf = tk.LabelFrame(outer, text="  Log  ", font=("Segoe UI", 8),
                           bg=C["bg"], fg=C["muted"], bd=1, relief=tk.GROOVE)
        lf.pack(fill=tk.BOTH, expand=True)
        self._hlog = scrolledtext.ScrolledText(lf, height=6,
                                                bg=C["panel"], fg=C["green"],
                                                font=("Courier", 8), relief=tk.FLAT,
                                                state=tk.DISABLED)
        self._hlog.pack(fill=tk.BOTH, expand=True)

    def _start_host(self):
        try:
            port = int(self._port_var.get())
        except:
            port = 8765

        self._pin = generate_pin()
        self._pin_lbl.config(text=f"PIN: {self._pin[:3]} {self._pin[3:]}", fg=C["yellow"])

        ip = get_local_ip()
        addr = f"{ip}:{port}"
        self._addr_lbl.config(text=addr, fg=C["accent"])
        self._start_btn.config(state=tk.DISABLED, text="✓ Active")
        self._hstatus.config(text="Waiting for viewer...", fg=C["yellow"])
        self._hdot.config(fg=C["yellow"])
        self._log_h(f"Server started — address: {addr}")
        self._log_h(f"PIN: {self._pin} — viewer needs this")
        self._log_h("Waiting for viewer to connect...")

        self.host_engine = HostEngine(
            port=port,
            fps_fn=lambda: self._fps_var.get(),
            quality_fn=lambda: self._quality_var.get(),
            pin=self._pin,
            on_event=lambda ev, n: self.after(0, lambda e=ev, c=n: self._host_event(e, c)),
            on_log=lambda m: self.after(0, lambda msg=m: self._log_h(msg)),
            on_chat=lambda text, frm: self.after(0, lambda t=text, fr=frm: self._host_chat(t, fr)),
            on_file=lambda name, size: None,
        )
        self.host_engine.start()

    def _host_event(self, event, count):
        if event == "connect":
            self._hstatus.config(text="🟢 Streaming — viewer connected", fg=C["green"])
            self._hdot.config(fg=C["green"])
            self._viewer_count.config(text=f"● {count} viewer(s)")
        elif event == "disconnect":
            if count == 0:
                self._hstatus.config(text="Waiting for viewer...", fg=C["yellow"])
                self._hdot.config(fg=C["yellow"])
                self._viewer_count.config(text="")
            else:
                self._viewer_count.config(text=f"● {count} viewer(s)")

    def _host_chat(self, text, frm):
        self._log_h(f"[{frm}] {text}")

    def _stop_host(self):
        if self.host_engine:
            self.host_engine.stop()
            self.host_engine = None
        if self.tunnel_engine:
            self.tunnel_engine.stop()
            self.tunnel_engine = None
        try:
            self._addr_lbl.config(text="Not started", fg=C["muted"])
            self._start_btn.config(state=tk.NORMAL, text="▶  Start Sharing")
            self._hstatus.config(text="Stopped", fg=C["muted"])
            self._hdot.config(fg=C["muted"])
            self._viewer_count.config(text="")
            self._pin_lbl.config(text="PIN: --- ---", fg=C["muted"])
            self._tunnel_lbl.config(text="Tunnel OFF — only works on same network", fg=C["muted"])
            self._tunnel_btn.config(text="Enable Tunnel", fg=C["yellow"])
            self._tunnel_addr = None
        except:
            pass
        self._log_h("Server stopped.")

    def _toggle_tunnel(self):
        if self.tunnel_engine:
            self.tunnel_engine.stop()
            self.tunnel_engine = None
            self._tunnel_lbl.config(text="Tunnel OFF — only works on same network", fg=C["muted"])
            self._tunnel_btn.config(text="Enable Tunnel", fg=C["yellow"])
            self._tunnel_addr = None
            try:
                ip = get_local_ip()
                port = int(self._port_var.get())
                self._addr_lbl.config(text=f"{ip}:{port}", fg=C["accent"])
            except:
                pass
            self._log_h("Tunnel disabled.")
            return

        try:
            port = int(self._port_var.get())
        except:
            port = 8765

        self._tunnel_btn.config(text="Connecting...", state=tk.DISABLED)
        self._tunnel_lbl.config(text="Starting Cloudflare tunnel...", fg=C["yellow"])
        self._log_h("Starting Cloudflare tunnel (free, worldwide)...")

        self.tunnel_engine = TunnelEngine(
            port=port,
            on_url=lambda u: self.after(0, lambda url=u: self._on_tunnel_url(url)),
            on_log=lambda m: self.after(0, lambda msg=m: self._log_h(msg)),
            on_error=lambda e: self.after(0, lambda err=e: self._on_tunnel_error(err)),
        )
        self.tunnel_engine.start()

    def _on_tunnel_url(self, url):
        self._tunnel_addr = url
        self._addr_lbl.config(text=url, fg=C["yellow"])
        self._tunnel_lbl.config(text=f"🌐 INTERNET TUNNEL ACTIVE: {url}", fg=C["green"])
        self._tunnel_btn.config(text="Disable Tunnel", fg=C["red"], state=tk.NORMAL)
        self._log_h(f"Tunnel active! Address: {url}")
        self._log_h(f"Viewer connects with: wss://{url}")
        self._log_h(f"PIN: {self._pin}")

    def _on_tunnel_error(self, err):
        first = err.split("\n")[0]
        self._tunnel_lbl.config(text=f"⚠ {first}", fg=C["red"])
        self._tunnel_btn.config(text="Enable Tunnel", state=tk.NORMAL, fg=C["yellow"])
        for line in err.split("\n"):
            if line.strip():
                self._log_h(line)

    def _copy_addr(self):
        addr = self._addr_lbl.cget("text")
        if addr and addr not in ("Not started",):
            self.clipboard_clear()
            self.clipboard_append(addr)
            self._copy_btn.config(text="✓ Copied!", fg=C["green"])
            self.after(2000, lambda: self._copy_btn.config(text="📋 Copy", fg=C["text"]))

    def _log_h(self, msg):
        try:
            ts = time.strftime("%H:%M:%S")
            self._hlog.config(state=tk.NORMAL)
            self._hlog.insert(tk.END, f"[{ts}] {msg}\n")
            self._hlog.see(tk.END)
            self._hlog.config(state=tk.DISABLED)
        except:
            pass

    def show_viewer(self):
        self._clear()
        self._set_nav("viewer")
        self.view = "viewer"

        outer = tk.Frame(self.content, bg=C["bg"], padx=40, pady=30)
        outer.pack(fill=tk.BOTH, expand=True)

        tk.Label(outer, text="Connect to Remote",
                 font=("Segoe UI", 18, "bold"), bg=C["bg"], fg=C["text"]).pack(anchor="w")
        tk.Label(outer, text="Enter the address and PIN your friend shared with you.",
                 font=("Segoe UI", 9), bg=C["bg"], fg=C["muted"]).pack(anchor="w", pady=(3, 22))

        tk.Label(outer, text="HOST ADDRESS", font=("Courier", 8),
                 bg=C["bg"], fg=C["muted"]).pack(anchor="w")

        irow = tk.Frame(outer, bg=C["bg"])
        irow.pack(fill=tk.X, pady=(6, 2))

        self._addr_var = tk.StringVar()
        self._addr_entry = tk.Entry(irow, textvariable=self._addr_var,
                                    font=("Courier", 15), bg=C["panel2"],
                                    fg=C["accent"], insertbackground=C["white"],
                                    relief=tk.FLAT, width=28)
        self._addr_entry.pack(side=tk.LEFT, ipady=9, padx=(0, 8))
        self._addr_entry.bind("<Return>", lambda e: self._do_connect())

        tk.Button(irow, text="📋 Paste", font=("Segoe UI", 9),
                  bg=C["panel"], fg=C["text"], relief=tk.FLAT,
                  padx=10, pady=6, cursor="hand2",
                  command=lambda: self._addr_var.set(self.clipboard_get())
                  ).pack(side=tk.LEFT)

        tk.Label(outer, text="PIN", font=("Courier", 8),
                 bg=C["bg"], fg=C["muted"]).pack(anchor="w", pady=(10, 2))

        pirow = tk.Frame(outer, bg=C["bg"])
        pirow.pack(fill=tk.X, pady=(0, 4))

        self._pin_var = tk.StringVar()
        self._pin_entry = tk.Entry(pirow, textvariable=self._pin_var,
                                   font=("Courier", 15), bg=C["panel2"],
                                   fg=C["yellow"], insertbackground=C["white"],
                                   relief=tk.FLAT, width=12, show="•")
        self._pin_entry.pack(side=tk.LEFT, ipady=9, padx=(0, 8))

        tk.Label(outer, text="Examples:  192.168.1.5:8765  or  abc-xyz.trycloudflare.com",
                 font=("Courier", 8), bg=C["bg"], fg=C["muted"]).pack(anchor="w", pady=(0, 18))

        self._conn_btn = tk.Button(outer, text="⚡  Connect Now",
                                   font=("Segoe UI", 11, "bold"),
                                   bg=C["accent"], fg=C["black"],
                                   relief=tk.FLAT, padx=20, pady=9,
                                   cursor="hand2", command=self._do_connect)
        self._conn_btn.pack(anchor="w")

        self._verr = tk.Label(outer, text="", font=("Segoe UI", 9),
                              bg=C["bg"], fg=C["red"])
        self._verr.pack(anchor="w", pady=(8, 0))

        tip = tk.Frame(outer, bg=C["panel"], padx=18, pady=14)
        tip.pack(fill=tk.X, pady=(24, 0))
        tk.Label(tip, text="📡  Connecting over the internet?",
                 font=("Segoe UI", 9, "bold"), bg=C["panel"], fg=C["text"]).pack(anchor="w")
        tk.Label(tip,
                 text="The host clicks 'Enable Tunnel' to get a worldwide address.\n"
                 "Paste that address here + the 6-character PIN shown on their screen.",
                 font=("Segoe UI", 9), bg=C["panel"], fg=C["muted"],
                 justify=tk.LEFT).pack(anchor="w", pady=(6, 0))

        self._addr_entry.focus_set()

    def _do_connect(self):
        addr = self._addr_var.get().strip()
        pin = self._pin_var.get().strip().upper()
        if not addr:
            self._verr.config(text="⚠  Enter the host address")
            return
        if not pin:
            self._verr.config(text="⚠  Enter the PIN")
            return
        if len(pin) != 6:
            self._verr.config(text="⚠  PIN must be 6 characters")
            return

        self._verr.config(text="")
        self._conn_btn.config(text="Connecting...", state=tk.DISABLED, bg=C["muted"])

        self.viewer_engine = ViewerEngine(
            on_frame=lambda data, w, h, rw, rh, left, top: self.after(
                0, lambda d=data, ww=w, hh=h, rrw=rw, rrh=rh, ll=left, tt=top:
                self._on_frame(d, ww, hh, rrw, rrh, ll, tt)),
            on_status=lambda s: self.after(0, lambda st=s: self._on_vstatus(st)),
            on_disconnect=lambda: self.after(0, self._on_vdisconnect),
            on_log=lambda m: self.after(0, lambda msg=m: self._log_v(msg)),
            on_chat=lambda text, frm: self.after(0, lambda t=text, fr=frm: self._on_vchat(t, fr)),
            on_file_progress=lambda name, pct: None,
        )
        self.viewer_engine.connect(addr, pin)

    def _on_vstatus(self, status):
        if status == "connected":
            self._show_remote()
        elif status == "auth_fail":
            self._verr.config(text="⚠  Wrong PIN! Ask the host for the correct PIN.")
            self._conn_btn.config(text="⚡  Connect Now", state=tk.NORMAL, bg=C["accent"])
        else:
            try:
                self._verr.config(text="⚠  Could not connect — is the host running?")
                self._conn_btn.config(text="⚡  Connect Now", state=tk.NORMAL, bg=C["accent"])
            except:
                pass

    def _show_remote(self):
        self._clear()
        self.view = "remote"

        bar = tk.Frame(self.content, bg=C["panel"], pady=7, padx=14)
        bar.pack(fill=tk.X)

        tk.Label(bar, text="⚡ QuickDesk Pro",
                 font=("Segoe UI", 9, "bold"), bg=C["panel"], fg=C["accent"]).pack(side=tk.LEFT)

        self._fps_lbl = tk.Label(bar, text="",
                                 font=("Courier", 8), bg=C["panel"], fg=C["green"])
        self._fps_lbl.pack(side=tk.LEFT, padx=14)

        self._conn_lbl = tk.Label(bar, text="🟢 Connected",
                                  font=("Segoe UI", 9), bg=C["panel"], fg=C["green"])
        self._conn_lbl.pack(side=tk.LEFT)

        tk.Button(bar, text="📁 Send File", font=("Segoe UI", 8),
                  bg=C["panel2"], fg=C["text"], relief=tk.FLAT,
                  padx=8, pady=3, cursor="hand2",
                  command=self._send_file).pack(side=tk.RIGHT, padx=4)

        tk.Button(bar, text="Disconnect", font=("Segoe UI", 9),
                  bg=C["panel2"], fg=C["red"], relief=tk.FLAT,
                  padx=10, pady=3, cursor="hand2",
                  command=self._do_disconnect).pack(side=tk.RIGHT)

        self._remote_w = 1920
        self._remote_h = 1080
        self._remote_left = 0
        self._remote_top = 0
        self._display_w = 0
        self._display_h = 0
        self._x_off = 0
        self._y_off = 0
        self._frame_count = 0
        self._fps_time = time.time()
        self._last_photo = None
        self._mods_held = set()
        self._kill_count = 0
        self._kill_time = 0

        self._canvas = tk.Canvas(self.content, bg=C["black"],
                                 cursor="none", highlightthickness=0)
        self._canvas.pack(fill=tk.BOTH, expand=True)

        self._cur = self._canvas.create_oval(0, 0, 14, 14,
                                              outline=C["accent"], width=2,
                                              fill="", tags="cursor")

        chat_frame = tk.Frame(self.content, bg=C["panel"], height=120)
        chat_frame.pack(fill=tk.X)
        chat_frame.pack_propagate(False)

        chat_top = tk.Frame(chat_frame, bg=C["panel"])
        chat_top.pack(fill=tk.X, padx=8, pady=(4, 0))
        tk.Label(chat_top, text="💬 Chat", font=("Segoe UI", 8, "bold"),
                 bg=C["panel"], fg=C["muted"]).pack(side=tk.LEFT)
        self._chat_clear = tk.Button(chat_top, text="Clear", font=("Segoe UI", 7),
                                     bg=C["panel2"], fg=C["muted"], relief=tk.FLAT,
                                     padx=6, pady=1, cursor="hand2",
                                     command=lambda: self._chat_log.delete(1.0, tk.END))
        self._chat_clear.pack(side=tk.RIGHT)

        self._chat_log = tk.Text(chat_frame, height=3,
                                 bg=C["panel"], fg=C["text"],
                                 font=("Segoe UI", 9), relief=tk.FLAT,
                                 state=tk.DISABLED)
        self._chat_log.pack(fill=tk.BOTH, expand=True, padx=8, pady=2)

        chat_input = tk.Frame(chat_frame, bg=C["panel"])
        chat_input.pack(fill=tk.X, padx=8, pady=(0, 4))
        self._chat_var = tk.StringVar()
        self._chat_entry = tk.Entry(chat_input, textvariable=self._chat_var,
                                    font=("Segoe UI", 10), bg=C["panel2"],
                                    fg=C["text"], insertbackground=C["white"],
                                    relief=tk.FLAT)
        self._chat_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=4, padx=(0, 4))
        self._chat_entry.bind("<Return>", lambda e: self._send_chat())
        tk.Button(chat_input, text="Send", font=("Segoe UI", 9),
                  bg=C["accent"], fg=C["black"], relief=tk.FLAT,
                  padx=10, pady=2, cursor="hand2",
                  command=self._send_chat).pack(side=tk.RIGHT)

        self._canvas.bind("<Enter>", lambda e: self._canvas.focus_set())
        self._canvas.bind("<Motion>", self._ev_move)
        self._canvas.bind("<ButtonPress-1>", self._ev_left_down)
        self._canvas.bind("<ButtonRelease-1>", lambda e: self._ev_btn_up(e, "left"))
        self._canvas.bind("<Double-Button-1>", self._ev_double)
        self._canvas.bind("<ButtonPress-3>", lambda e: self._ev_btn_down(e, "right"))
        self._canvas.bind("<ButtonRelease-3>", lambda e: self._ev_btn_up(e, "right"))
        self._canvas.bind("<ButtonPress-2>", lambda e: self._ev_btn_down(e, "middle"))
        self._canvas.bind("<ButtonRelease-2>", lambda e: self._ev_btn_up(e, "middle"))
        self._canvas.bind("<MouseWheel>", self._ev_scroll)
        self._canvas.bind("<Button-4>", lambda e: self._ev_scroll_linux(e, 3))
        self._canvas.bind("<Button-5>", lambda e: self._ev_scroll_linux(e, -3))
        self.bind("<KeyPress>", self._ev_key_down)
        self.bind("<KeyRelease>", self._ev_key_up)

        self._log_v("Connected to remote screen")
        self.after(100, self._canvas.focus_set)

    def _log_v(self, msg):
        pass

    def _send_chat(self):
        text = self._chat_var.get().strip()
        if not text or not self.viewer_engine:
            return
        self._chat_var.set("")
        self._append_chat(f"You: {text}")
        self.viewer_engine.send_text({"type": "chat", "text": text})

    def _append_chat(self, text):
        try:
            self._chat_log.config(state=tk.NORMAL)
            self._chat_log.insert(tk.END, f"{text}\n")
            self._chat_log.see(tk.END)
            self._chat_log.config(state=tk.DISABLED)
        except:
            pass

    def _on_vchat(self, text, frm):
        label = "Host" if frm == "host" else "Viewer"
        self._append_chat(f"{label}: {text}")

    def _send_file(self):
        if not self.viewer_engine:
            return
        path = filedialog.askopenfilename(title="Select file to send")
        if not path:
            return
        self._log_v(f"Sending file: {os.path.basename(path)}...")
        threading.Thread(target=self._send_file_worker, args=(path,), daemon=True).start()

    def _send_file_worker(self, path):
        try:
            name = os.path.basename(path)
            size = os.path.getsize(path)
            file_id = str(int(time.time() * 1000))

            self.viewer_engine.send_text({"type": "file_start", "id": file_id, "name": name, "size": size})

            with open(path, "rb") as f:
                seq = 0
                while True:
                    chunk = f.read(FILE_CHUNK_SIZE)
                    if not chunk:
                        break
                    self.viewer_engine.send_binary(
                        {"type": "file_chunk", "id": file_id, "seq": seq},
                        chunk,
                    )
                    seq += 1
                    time.sleep(0.01)

            self.viewer_engine.send_text({"type": "file_end", "id": file_id})
            self.after(0, lambda: self._append_chat(f"📁 Sent: {name}"))
        except Exception as e:
            self.after(0, lambda: self._log_v(f"File send error: {e}"))

    def _on_frame(self, jpeg_bytes, fw, fh, rw, rh, left, top):
        try:
            self._remote_w = rw
            self._remote_h = rh
            self._remote_left = left
            self._remote_top = top

            cw = self._canvas.winfo_width() or 800
            ch = self._canvas.winfo_height() or 600

            ratio = min(cw / fw, ch / fh)
            dw = max(1, int(fw * ratio))
            dh = max(1, int(fh * ratio))

            self._display_w = dw
            self._display_h = dh
            self._x_off = (cw - dw) // 2
            self._y_off = (ch - dh) // 2

            img = Image.open(io.BytesIO(jpeg_bytes))
            img = img.resize((dw, dh), Image.BILINEAR)
            photo = ImageTk.PhotoImage(img)

            self._canvas.delete("frame")
            self._canvas.create_image(self._x_off, self._y_off,
                                      anchor=tk.NW, image=photo, tags="frame")
            self._canvas.tag_raise("cursor")
            self._last_photo = photo

            self._frame_count += 1
            now = time.time()
            elapsed = now - self._fps_time
            if elapsed >= 1.0:
                fps = self._frame_count / elapsed
                try:
                    self._fps_lbl.config(text=f"📡 {fps:.0f} fps")
                except:
                    pass
                self._frame_count = 0
                self._fps_time = now
        except:
            pass

    def _to_remote(self, cx, cy):
        if self._display_w == 0 or self._display_h == 0:
            return 0, 0
        img_x = int((cx - self._x_off) / self._display_w * self._remote_w)
        img_y = int((cy - self._y_off) / self._display_h * self._remote_h)
        img_x = max(0, min(self._remote_w - 1, img_x))
        img_y = max(0, min(self._remote_h - 1, img_y))
        virtual_x = self._remote_left + img_x
        virtual_y = self._remote_top + img_y
        return virtual_x, virtual_y

    def _send(self, data):
        if self.viewer_engine:
            self.viewer_engine.send_text(data)

    def _ev_move(self, e):
        self._canvas.coords("cursor", e.x - 7, e.y - 7, e.x + 7, e.y + 7)
        if self._display_w > 0:
            rx, ry = self._to_remote(e.x, e.y)
            self._send({"type": "mouse_move", "x": rx, "y": ry})

    def _ev_left_down(self, e):
        self._canvas.focus_set()
        if self._display_w > 0:
            rx, ry = self._to_remote(e.x, e.y)
            self._send({"type": "mouse_click", "x": rx, "y": ry, "button": "left"})

    def _ev_btn_down(self, e, button):
        self._canvas.focus_set()
        if self._display_w > 0:
            rx, ry = self._to_remote(e.x, e.y)
            self._send({"type": "mouse_down", "x": rx, "y": ry, "button": button})
            self._send({"type": "mouse_click", "x": rx, "y": ry, "button": button})

    def _ev_btn_up(self, e, button):
        if self._display_w > 0:
            rx, ry = self._to_remote(e.x, e.y)
            self._send({"type": "mouse_up", "x": rx, "y": ry, "button": button})

    def _ev_double(self, e):
        if self._display_w > 0:
            rx, ry = self._to_remote(e.x, e.y)
            self._send({"type": "mouse_double", "x": rx, "y": ry})

    def _ev_scroll(self, e):
        if self._display_w > 0:
            rx, ry = self._to_remote(e.x, e.y)
            amt = 3 if e.delta > 0 else -3
            self._send({"type": "mouse_scroll", "x": rx, "y": ry, "amount": amt})

    def _ev_scroll_linux(self, e, amt):
        if self._display_w > 0:
            rx, ry = self._to_remote(e.x, e.y)
            self._send({"type": "mouse_scroll", "x": rx, "y": ry, "amount": amt})

    def _ev_key_down(self, e):
        if self.view != "remote" or not self.viewer_engine:
            return

        sym = e.keysym
        self._mods_held.add(sym)

        if sym in ("Control_L", "Control_R") and "q" in [k.lower() for k in self._mods_held]:
            now = time.time()
            if now - self._kill_time < 2:
                self._kill_count += 1
            else:
                self._kill_count = 1
            self._kill_time = now
            if self._kill_count >= 3:
                self._kill_count = 0
                self._do_disconnect()
                return

        special = TK_SPECIAL.get(sym)
        if special:
            self._send({"type": "key_press", "key": special})
            return

        mod_map = {
            "Control_L": "ctrl", "Control_R": "ctrl",
            "Shift_L": "shift", "Shift_R": "shift",
            "Alt_L": "alt", "Alt_R": "alt",
            "Super_L": "win", "Super_R": "win",
        }
        if sym in mod_map:
            self._send({"type": "key_down", "key": mod_map[sym]})
            return

        has_ctrl = any(m in ("Control_L", "Control_R") for m in self._mods_held)
        has_shift = any(m in ("Shift_L", "Shift_R") for m in self._mods_held)
        has_alt = any(m in ("Alt_L", "Alt_R") for m in self._mods_held)

        if (has_ctrl or has_shift or has_alt) and e.char and e.char.isprintable():
            keys = []
            if has_ctrl:
                keys.append("ctrl")
            if has_shift:
                keys.append("shift")
            if has_alt:
                keys.append("alt")
            keys.append(e.char.lower())
            self._send({"type": "key_combo", "keys": keys})
            return

        if e.char and e.char.isprintable():
            self._send({"type": "type_text", "text": e.char})

    def _ev_key_up(self, e):
        sym = e.keysym
        self._mods_held.discard(sym)
        mod_map = {
            "Control_L": "ctrl", "Control_R": "ctrl",
            "Shift_L": "shift", "Shift_R": "shift",
            "Alt_L": "alt", "Alt_R": "alt",
            "Super_L": "win", "Super_R": "win",
        }
        if sym in mod_map:
            self._send({"type": "key_up", "key": mod_map[sym]})

    def _on_vdisconnect(self):
        try:
            self._conn_lbl.config(text="🔴 Disconnected", fg=C["red"])
        except:
            pass
        self.after(1500, self.show_viewer)

    def _do_disconnect(self):
        if self.viewer_engine:
            self.viewer_engine.disconnect()
            self.viewer_engine = None
        self.unbind("<KeyPress>")
        self.unbind("<KeyRelease>")
        self.show_viewer()

    def _quit(self):
        if self.host_engine:
            self.host_engine.stop()
        if self.viewer_engine:
            self.viewer_engine.disconnect()
        if self.tunnel_engine:
            self.tunnel_engine.stop()
        self.destroy()
        sys.exit(0)


if __name__ == "__main__":
    print("QuickDesk Pro v4 — Starting...")
    app = QuickDeskApp()
    app.mainloop()
